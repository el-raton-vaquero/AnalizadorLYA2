"""
Paquete principal del compilador.
"""
