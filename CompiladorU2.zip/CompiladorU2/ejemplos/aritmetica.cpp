int x = 3 + 4 * 2;
