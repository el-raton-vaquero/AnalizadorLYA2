if (a > b) {
    x = 1;
} else {
    x = 2;
}
